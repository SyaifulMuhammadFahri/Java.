package Project;
import java.util.Scanner;

public class Java {
    
    /**
     * Project Java
     * @param args
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        Java warung = new Java();
        
        Scanner scan = new Scanner(System.in);
        System.out.println("    APLIKASI PENJUALAN MAKANAN   ");
        System.out.println("    WARUNG MASAKAN BETAWI ASLI   ");
        System.out.println("=================================");
        System.out.println("         MENU MAKANAN            ");
        System.out.println("=================================");
        System.out.println("|NO|  NAMA MAKANAN               ");
        System.out.println("|1.|   NASI UDUK          Rp.20.000.- ");
        System.out.println("|2.|   SOP IGA            Rp.25.000.- ");
        System.out.println("|3.|   NASI BAKAR BAMBU   Rp.13.000.- ");
        System.out.println("|4.|   NASI KUNING        Rp.10.000.-  ");
        System.out.println("|5.|   SEMUR JENGKOL      Rp.15.000.- ");
        System.out.println("|6.|   NASI KUCING        Rp.6.000.-  ");
        System.out.println("|7.|   SAYUR ASEM         Rp.20.000.- ");
        System.out.println("==================================");
        
        int harga = 0;
        int hm1 = 20000, hm2 = 25000, hm3 = 13000, hm4 = 10000, hm5 = 15000, hm6 = 6000, hm7 = 20000;
        String MAKANAN;
        
        for (String i = "YA"; i.equals("YA")|| i.equals("YA");)
        {
            System.out.println("_____________________________________________");
            System.out.println("Masukan Nomer Pesanan Anda : ");
            int Nomer = scan.nextInt();
            System.out.println("_____________________________________________");
            System.out.println("");
           
        switch(Nomer){
            case 1:
                 MAKANAN = " NASI UDUK RP 20.000.-";
                 System.out.println("Nomer Pesanan Anda = " + Nomer+"." + MAKANAN);
                 harga = harga+hm1;
                 break;
            case 2:
                MAKANAN = " SOP IGA RP 25.000.-";
                System.out.println("Nomer Pesanan Anda = " + Nomer+"." + MAKANAN);
                harga = harga+hm2;
                break;
            case 3:
                MAKANAN = " NASI BAKAR BAMBU RP 13.000.-";
                System.out.println("Nomer Pesanan Anda = " + Nomer+"." + MAKANAN);
                harga = harga+hm3;
                break;
            case 4:
                MAKANAN = " NASI KUNING RP 10.000.-";
                System.out.println("Nomer Pesanan Anda = " + Nomer+"." + MAKANAN);
                harga = harga+hm4;
                break;
            case 5:
                MAKANAN = " SEMUR JENGKOL RP 15.000.-";
                System.out.println("Nomer Pesanan Anda = " + Nomer+"." + MAKANAN);
                harga = harga+hm5;
                break;
            case 6:
                MAKANAN = " NASI KUCING RP 6.000.-";
                System.out.println("Nomer Pesanan Anda = " + Nomer+"." + MAKANAN);
                harga = harga+hm6;
                break;
            case 7:
                MAKANAN = " SAYUR ASEM RP 20.000.-";
                System.out.println("Nomer Pesanan Anda = " + Nomer+"." + MAKANAN);
                harga = harga+hm7;
                break;
                default:
                System.out.println("Nomor Yang Anda Pilih Tidak Ada Di MENU");
        }
       
        
        System.out.println("__________________________________________________________________");
        System.out.println("Apakah Anda Ingin Membei Makanan Lainnya?" + " YA/TIDAK ");
        i = scan.next();
        }
        System.out.println("__________________________________________________________________");
        System.out.println("Total Keseluruhan Pembayaran Makanan Anda Sebesar Rp." +harga+".-");
        System.out.println("                  ....>>>TERIMA KASIH<<<....                      ");
    }
}

